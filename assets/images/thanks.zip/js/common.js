// headerAccodion
$(function(){
    $(".accBox .naviBtn").click(function(){
        $(this).toggleClass("active").next().slideToggle(800,'easeInOutQuint').toggleClass("active");
    });
	$(".accBox ul li a").click(function(){
		$(this).parents(".accBox").find(".naviBtn").toggleClass("active");
    });
});

// footer banner slider
$(function(){
	$('.footer-slider').slick({
		arrows: false,
        slidesToShow: 4,
        slidesToScroll: 1,
        dots: false,
        centerMode: true,
        centerPadding: '0',
        infinite: true,
        autoplay: true,
        responsive: [
	    {
	      breakpoint: 769,      // 480〜768px
	      settings: {
	        slidesToShow: 3,
	      }
	    },
	    {
	      breakpoint: 481,      // 〜480px
	      settings: {
	        slidesToShow: 1,
	        centerPadding: '20%',
	      }
	    }
	  ],
    });
});

// footer fixed navi
$(function(){
	
	var $btn = $('.fixedNav');
	var isHidden = true;

	$btn.hide();
	
	$(window).scroll(function () {
		if( $(this).scrollTop() > 400 ) {
			if( isHidden ) {
				$btn.stop(true,true).fadeIn();
				isHidden = false;
			}
		} else {
			if( !isHidden ) {
				$btn.stop(true,true).fadeOut();
				isHidden = true;
			}
		}
	});
});

// tellink
$(function(){
    var ua = navigator.userAgent;
    if(ua.indexOf('iPhone') < 0 && ua.indexOf('Android') < 0){
        $('.telhref .delete').each(function(){
            $(this).unwrap();
        });
    }
});



// smoothscroll # start

$(function(){
   $('a[href^=#]' + 'a:not(.not)').click(function() {
      var speed = 1200;
      var href= $(this).attr("href");
      var target = $(href == "#" || href == "" ? 'html' : href);
      var position = target.offset().top ;
	  if ((navigator.userAgent.indexOf('iPhone') > 0 && navigator.userAgent.indexOf('iPad') == -1) || navigator.userAgent.indexOf('iPod') > 0 || (navigator.userAgent.indexOf('Android') > 0 && navigator.userAgent.indexOf('Mobile') > 0)){
      var position = target.offset().top - 100;
	  }else{
      var position = target.offset().top - 110;
	  }
	  $('body,html').animate({scrollTop:position}, speed, 'easeInOutExpo');
      return false;
   });
});



// smoothscroll ?id= start

$(window).on('load',function(){
    var urlParam = location.search.substring(1);
    if(urlParam) {
	  var param = urlParam.split('&');
	  var paramArray = [];
	  for (i = 0; i < param.length; i++) {
	    var paramItem = param[i].split('=');
	    paramArray[paramItem[0]] = paramItem[1];
	  }
	  var hash   = '#' + paramArray.id;
      var tgt    = $(hash);
      if ((navigator.userAgent.indexOf('iPhone') > 0 && navigator.userAgent.indexOf('iPad') == -1) || navigator.userAgent.indexOf('iPod') > 0 || (navigator.userAgent.indexOf('Android') > 0 && navigator.userAgent.indexOf('Mobile') > 0)){
		var pos    = tgt.offset().top -100;
		} else{
        var pos    = tgt.offset().top -110;
		}

	  if (hash) {
	    $("html, body").animate({scrollTop:pos}, 1200, "easeInOutExpo");
	  }
	}
});
	